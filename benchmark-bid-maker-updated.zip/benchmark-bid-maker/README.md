# Benchmark Bid Maker

This package contains the three supplied Bid Maker source files plus local image assets.

## Run
Open `index.html` in a modern browser. The app uses browser local storage for its saved price list. The PDF library is loaded from a CDN, so internet access is needed for that external library.

## Changes in this working copy
- Removed duplicate touch handlers; pointer events now handle mouse, touch, and stylus input.
- Scaled drawing coordinates to the displayed canvas size for smaller screens.
- Corrected undo history so undoing the first drawing action returns to a blank grid.
- Corrected copper and galvalume percentage markup calculations.
- Corrected A/B elbow price selection for round, smooth, custom, and standard downspout types.
- Added tablet/phone layout rules and local SVG logo, icon, and close-button assets.

## Important
The SVG logo is a clean text-based placeholder, not an original Benchmark logo file. Replace it with the company's approved logo if one is available.

This is a local working copy. It has not been pushed to GitHub or deployed.
